public class NOME {
	public static void main(String[] args) {
		
		String asterisco = "*";
		String underLine = " ";
		for (int linha = 0; linha <= 5; linha++) {

			for (int coluna = 0; coluna < 7; coluna++) {
				
				//g
				if (linha == 0 && coluna != 6 || linha == 5 && coluna != 6) {
					System.out.print(asterisco);
				} else if (coluna == 0) {
					System.out.print(asterisco);
				} else if (coluna == 5 && linha != 3 && linha != 1 && linha != 2) {
					System.out.print(asterisco);
				} else if (coluna != 1 && coluna != 2 && coluna != 3 && coluna != 6 && linha == 3) {
					System.out.print(asterisco);
				} else {
					System.out.print(underLine);
				}

			}
			//u
			for (int coluna2 = 0; coluna2 < 6; coluna2++) {
				if (linha == 5 && coluna2 != 6) {
					System.out.print(asterisco);
				} else if (coluna2 == 0 || coluna2 == 5) {
					System.out.print(asterisco);
				} else {
					System.out.print(underLine);
				}

			}
			//i
			for (int coluna3 = 0; coluna3 < 7; coluna3++) {
				if (coluna3 == 3 && linha != 1) {
					System.out.print(asterisco);
				} else {
					System.out.print(underLine);
				}

			} 
			//l
			for (int coluna4 = 0; coluna4 < 7; coluna4++) {
				if (coluna4 == 0 || linha == 5 && coluna4 != 6) {
					System.out.print(asterisco);
				} else {
					System.out.print(underLine);
				}

			}//h
			for (int coluna5 = 0; coluna5 < 7; coluna5++) {
				if (coluna5 == 0 || coluna5 == 5 || linha == 2 && coluna5 != 6) {
					System.out.print(asterisco);
				} else {
					System.out.print(underLine);
				}

			}//e
			for (int coluna6 = 0; coluna6 < 7; coluna6++) {
				if (coluna6 == 0 || linha == 0 && coluna6 != 6 || linha == 5 && coluna6 != 6
						|| linha == 2 && coluna6 != 6) {
					System.out.print(asterisco);
				} else {
					System.out.print(underLine);
				}

			}//r
			for (int coluna6 = 0; coluna6 < 7; coluna6++) {
				if (coluna6 == 0 || linha == 0 && coluna6 != 6 || linha == 2 && coluna6 != 6) {
					System.out.print(asterisco);
				} else if (coluna6 == 5 && linha == 1 || coluna6 == 5 && linha == 1) {
					System.out.print(asterisco);
				} else if (coluna6 == 3 && linha == 2 || coluna6 == 3 && linha == 3 || 
						coluna6 == 4 && linha == 4 || coluna6 == 5 && linha == 5) {
					System.out.print(asterisco);
				}

				else {
					System.out.print(underLine);
				}

			}//r
			for (int coluna6 = 0; coluna6 < 7; coluna6++) {
				if (coluna6 == 0 || coluna6 == 5) {
					System.out.print(asterisco);
				} else if (coluna6 == 1 && linha == 1 || coluna6 == 2 && linha == 2) {
					System.out.print(asterisco);
				} else if (coluna6 == 3 && linha == 2 || coluna6 == 4 && linha == 1) {
					System.out.print(asterisco);
				}

				else {
					System.out.print(underLine);
				}

			}//m
			for (int coluna6 = 0; coluna6 < 7; coluna6++) {
				if (coluna6 == 0 || linha == 0 && coluna6 != 6 || linha == 5 && coluna6 != 6
						|| linha == 2 && coluna6 != 6) {
					System.out.print(asterisco);
				} else {
					System.out.print(underLine);
				}
			}
			System.out.println();

		}
	}
}
